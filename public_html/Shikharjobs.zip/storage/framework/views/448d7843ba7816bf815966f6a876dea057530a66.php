<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-venus-double" aria-hidden="true"></i> <span class="title">Genders</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.genders')); ?>" class="nav-link "> <span class="title">List Genders</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.gender')); ?>" class="nav-link "> <span class="title">Add new Gender</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.genders')); ?>" class="nav-link "> <span class="title">Sort Genders</span> </a> </li>
    </ul>
</li><?php /**PATH /home/admin/web/job.theblackshort.com/public_html/resources/views/admin/shared/side_bars/gender.blade.php ENDPATH**/ ?>