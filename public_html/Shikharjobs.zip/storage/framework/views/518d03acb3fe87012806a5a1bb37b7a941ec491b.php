<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-pie-chart" aria-hidden="true"></i> <span class="title">Job Experiences</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.job.experiences')); ?>" class="nav-link ">  <span class="title">List Job Experiences</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.job.experience')); ?>" class="nav-link ">  <span class="title">Add new Job Experience</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.job.experiences')); ?>" class="nav-link ">  <span class="title">Sort Job Experiences</span> </a> </li>
    </ul>
</li><?php /**PATH /home/admin/web/job.theblackshort.com/public_html/resources/views/admin/shared/side_bars/job_experience.blade.php ENDPATH**/ ?>