<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-globe" aria-hidden="true"></i> <span class="title">Cities</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.cities')); ?>" class="nav-link "> <span class="title">List Cities</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.city')); ?>" class="nav-link "> <span class="title">Add new City</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.cities')); ?>" class="nav-link "> <span class="title">Sort Cities</span> </a> </li>
    </ul>
</li><?php /**PATH /home/admin/web/shikharjobs.com/public_html/resources/views/admin/shared/side_bars/city.blade.php ENDPATH**/ ?>