<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-level-up" aria-hidden="true"></i> <span class="title">Sliders</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.sliders')); ?>" class="nav-link ">  <span class="title">List Sliders</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.slider')); ?>" class="nav-link ">  <span class="title">Add new Slider</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.sliders')); ?>" class="nav-link "> <span class="title">Sort Sliders</span> </a> </li>
    </ul>
</li><?php /**PATH /home/admin/web/job.theblackshort.com/public_html/resources/views/admin/shared/side_bars/slider.blade.php ENDPATH**/ ?>