<div class="col-md-3 col-sm-4">
	<div class="usernavwrap">
    <ul class="usernavdash">
        <li class="active"><a href="<?php echo e(route('company.home')); ?>"><i class="fa fa-tachometer" aria-hidden="true"></i> <?php echo e(__('Dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('company.profile')); ?>"><i class="fa fa-pencil" aria-hidden="true"></i> <?php echo e(__('Edit Profile')); ?></a></li>
        <li><a href="<?php echo e(route('company.detail', Auth::guard('company')->user()->slug)); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('Company Public Profile')); ?></a></li>
        <li><a href="<?php echo e(route('post.job')); ?>"><i class="fa fa-desktop" aria-hidden="true"></i> <?php echo e(__('Post Job')); ?></a></li>
        <li><a href="<?php echo e(route('posted.jobs')); ?>"><i class="fa fa-black-tie" aria-hidden="true"></i> <?php echo e(__('Company Jobs')); ?></a></li>

        <li><a href="<?php echo e(route('company.packages')); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('CV Search Packages')); ?></a></li>
        
        <li><a href="<?php echo e(route('company.unloced-users')); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('Unlocked Users')); ?></a></li>

        <li><a href="<?php echo e(route('company.messages')); ?>"><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(__('Company Messages')); ?></a></li>
        <li><a href="<?php echo e(route('company.followers')); ?>"><i class="fa fa-users" aria-hidden="true"></i> <?php echo e(__('Company Followers')); ?></a></li>
        <li><a href="<?php echo e(route('company.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out" aria-hidden="true"></i> <?php echo e(__('Logout')); ?></a>
            <form id="logout-form" action="<?php echo e(route('company.logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
        </li>
    </ul>
	</div>
    <div class="row">
        <div class="col-md-12"><?php echo $siteSetting->dashboard_page_ad; ?></div>
    </div>
</div><?php /**PATH /home/admin/web/shikharjobs.com/public_html/resources/views/includes/company_dashboard_menu.blade.php ENDPATH**/ ?>