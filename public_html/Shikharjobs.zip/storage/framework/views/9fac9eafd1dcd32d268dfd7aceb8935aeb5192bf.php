<?php if((string)$siteSetting->facebook_address !== ''): ?>
<span style="margin-right:3px;"> <a href="<?php echo e($siteSetting->facebook_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_facebook_278425.png" alt="Facebook"></a> </span>
<?php endif; ?>
<?php if((string)$siteSetting->google_plus_address !== ''): ?>
<span style="margin-right:3px;"> <a href="<?php echo e($siteSetting->google_plus_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_gplus_278421.png" alt="Google+"></a> </span>
<?php endif; ?>
<?php if((string)$siteSetting->pinterest_address !== ''): ?>
<span style="margin-right:3px;"><a href="<?php echo e($siteSetting->pinterest_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_pinterest_278418.png" alt="Pinterest"></a></span>
<?php endif; ?>
<?php if((string)$siteSetting->twitter_address !== ''): ?>
<span style="margin-right:3px;"><a href="<?php echo e($siteSetting->twitter_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_twitter_278411.png" alt="Twitter"></a></span>
<?php endif; ?>
<?php if((string)$siteSetting->instagram_address !== ''): ?>
<span style="margin-right:3px;"><a href="<?php echo e($siteSetting->instagram_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_instagram_278420.png" alt="Instagram"></a></span>
<?php endif; ?>
<?php if((string)$siteSetting->linkedin_address !== ''): ?>
<span style="margin-right:3px;"><a href="<?php echo e($siteSetting->linkedin_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_linkedin_278419.png" alt="Linkedin"></a></span>
<?php endif; ?>
<?php if((string)$siteSetting->youtube_address !== ''): ?>
<span style="margin-right:3px;"><a href="<?php echo e($siteSetting->youtube_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_yt_278407.png" alt="YouTube"></a></span>
<?php endif; ?>
<?php if((string)$siteSetting->tumblr_address !== ''): ?>
<span style="margin-right:3px;"><a href="<?php echo e($siteSetting->tumblr_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_twittert_278410.png" alt="Tumblr"></a></span>
<?php endif; ?>
<?php if((string)$siteSetting->flickr_address !== ''): ?>
<span style="margin-right:3px;"><a href="<?php echo e($siteSetting->flickr_address); ?>"><img src="<?php echo e(asset('/')); ?>admin_assets/images/small_social_icons/if_flickr_278423.png" alt="Flickr"></a></span>
<?php endif; ?><?php /**PATH /home/admin/web/job.theblackshort.com/public_html/resources/views/admin/layouts/email_template_social.blade.php ENDPATH**/ ?>