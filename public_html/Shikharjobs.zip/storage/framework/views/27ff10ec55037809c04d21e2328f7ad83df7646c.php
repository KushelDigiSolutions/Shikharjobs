<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-building-o" aria-hidden="true"></i> <span class="title">Industries</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.industries')); ?>" class="nav-link "> <span class="title">List Industries</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.industry')); ?>" class="nav-link "> <span class="title">Add new Industry</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.industries')); ?>" class="nav-link "> <span class="title">Sort Industries</span> </a> </li>
    </ul>
</li><?php /**PATH /home/admin/web/shikharjobs.com/public_html/resources/views/admin/shared/side_bars/industry.blade.php ENDPATH**/ ?>