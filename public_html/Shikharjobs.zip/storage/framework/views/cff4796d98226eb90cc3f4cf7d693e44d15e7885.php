<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-briefcase" aria-hidden="true"></i> <span class="title">Job Types</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.job.types')); ?>" class="nav-link"> <span class="title">List Job Types</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.job.type')); ?>" class="nav-link"> <span class="title">Add new Job Type</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.job.types')); ?>" class="nav-link"> <span class="title">Sort Job Types</span> </a> </li>
    </ul>
</li><?php /**PATH /home/admin/web/job.theblackshort.com/public_html/resources/views/admin/shared/side_bars/job_type.blade.php ENDPATH**/ ?>