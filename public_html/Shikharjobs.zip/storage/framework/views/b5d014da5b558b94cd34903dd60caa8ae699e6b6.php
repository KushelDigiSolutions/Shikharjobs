<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-money" aria-hidden="true"></i> <span class="title">Salary Periods</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.salary.periods')); ?>" class="nav-link ">  <span class="title">List Salary Periods</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.salary.period')); ?>" class="nav-link ">  <span class="title">Add new Salary Period</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.salary.periods')); ?>" class="nav-link "> <span class="title">Sort Salary Periods</span> </a> </li>
    </ul>
</li><?php /**PATH /home/admin/web/job.theblackshort.com/public_html/resources/views/admin/shared/side_bars/salary_period.blade.php ENDPATH**/ ?>