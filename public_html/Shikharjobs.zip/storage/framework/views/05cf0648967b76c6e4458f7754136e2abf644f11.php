<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-university" aria-hidden="true"></i> <span class="title">Functional Areas</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.functional.areas')); ?>" class="nav-link "> <span class="title">List Functional Areas</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.functional.area')); ?>" class="nav-link "> <span class="title">Add new Functional Area</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.functional.areas')); ?>" class="nav-link "> <span class="title">Sort Functional Areas</span> </a> </li>
    </ul>
</li><?php /**PATH /home/admin/web/shikharjobs.com/public_html/resources/views/admin/shared/side_bars/functional_area.blade.php ENDPATH**/ ?>