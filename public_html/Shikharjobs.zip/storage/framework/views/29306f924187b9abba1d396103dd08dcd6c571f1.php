<?php $__env->startSection('content'); ?>
<!-- Header start -->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header end -->
<!-- Inner Page Title start -->
<?php echo $__env->make('includes.inner_page_title', ['page_title'=>__('Cvs Search Packages')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Inner Page Title end -->
<?php $company = Auth::guard('company')->user(); ?>
<div class="listpgWraper">
    <div class="container"><?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row"> <?php echo $__env->make('includes.company_dashboard_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-9 col-sm-8">
                <?php if(null!==($success_package) && !empty($success_package)): ?>
                <div class="instoretxt">
                <div class="credit"><?php echo e(__('Your Package is')); ?>: <strong><?php echo e($success_package->package_title); ?> - <?php echo e($siteSetting->default_currency_code); ?><?php echo e($success_package->package_price); ?></strong></div>
                <div class="credit"><?php echo e(__('Package Duration')); ?> : <strong><?php echo e(Carbon\Carbon::parse($company->cvs_package_start_date)->format('d M, Y')); ?></strong> - <strong><?php echo e(Carbon\Carbon::parse($company->cvs_package_end_date)->format('d M, Y')); ?></strong></div>
                <div class="credit"><?php echo e(__('Availed quota')); ?> : <strong><?php echo e($company->availed_cvs_quota); ?></strong> - <strong><?php echo e($company->cvs_quota); ?></strong></div>

            </div>
            <?php endif; ?>
                
                        <div class="paypackages">
    <!---four-paln-->
    <?php 
        $package = Auth::guard('company')->user()->cvs_getPackage();
     ?>
     <?php if(null!==($package)): ?>
       <div class="four-plan">
        <h3><?php echo e(__('Upgrade Package')); ?></h3>
        <div class="row"> <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <ul class="boxes">
                    <li class="icon"><i class="fa fa-paper-plane" aria-hidden="true"></i></li>
                    <li class="plan-name"><?php echo e($package->package_title); ?></li>
                    <li>
                        <div class="main-plan">
                            <div class="plan-price1-1">$</div>
                            <div class="plan-price1-2"><?php echo e($package->package_price); ?></div>
                            <div class="clearfix"></div>
                        </div>
                    </li>
                    <?php if($package->package_for=='cv_search'): ?>
                    <li class="plan-pages"><?php echo e(__('Can search seekrs')); ?> : <?php echo e($package->package_num_listings); ?></li>
                    <?php else: ?>
                    <li class="plan-pages"><?php echo e(__('Can post jobs')); ?> : <?php echo e($package->package_num_listings); ?></li>
                    <?php endif; ?>

                    <li class="plan-pages"><?php echo e(__('Package Duration')); ?> : <?php echo e($package->package_num_days); ?> <?php echo e(__('Days')); ?></li>
                    <?php if((bool)$siteSetting->is_paypal_active): ?>
                    <li class="order paypal"><a href="<?php echo e(route('order.upgrade.package', $package->id)); ?>"><i class="fa fa-cc-paypal" aria-hidden="true"></i> <?php echo e(__('pay with paypal')); ?></a></li>
                    <?php endif; ?>
                    <?php if((bool)$siteSetting->is_stripe_active): ?>
                    <li class="order"><a href="<?php echo e(route('stripe.order.form', [$package->id, 'upgrade'])); ?>"><i class="fa fa-cc-stripe" aria-hidden="true"></i> <?php echo e(__('pay with stripe')); ?></a></li>
                    <?php endif; ?>
                    <?php if((bool)$siteSetting->is_payu_active): ?>
                       <li class="order payu"><a href="<?php echo e(route('payu.order.cvsearch.package', ['package_id='.$package->id, 'type=upgrade'])); ?>"><?php echo e(__('pay with PayU')); ?></a></li>
                    <?php endif; ?>

                </ul>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
    </div>
     <?php else: ?>
    <div class="four-plan">
        <h3><?php echo e(__('Our Cvs Search Packages')); ?></h3>
        <div class="row"> <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <ul class="boxes">
                    <li class="icon"><i class="fa fa-paper-plane" aria-hidden="true"></i></li>
                    <li class="plan-name"><?php echo e($package->package_title); ?></li>
                    <li>
                        <div class="main-plan">
                            <div class="plan-price1-1"><?php echo e($siteSetting->default_currency_code); ?></div>
                            <div class="plan-price1-2"><?php echo e($package->package_price); ?></div>
                            <div class="clearfix"></div>
                        </div>
                    </li>
                    <?php if($package->package_for == 'cv_search'): ?>
                    <li class="plan-pages"><?php echo e(__('Can search seekrs')); ?> : <?php echo e($package->package_num_listings); ?></li>
                    <?php else: ?>
                    <li class="plan-pages"><?php echo e(__('Can post jobs')); ?> : <?php echo e($package->package_num_listings); ?></li>
                    <?php endif; ?>
                    <li class="plan-pages"><?php echo e(__('Package Duration')); ?> : <?php echo e($package->package_num_days); ?> <?php echo e(__('Days')); ?></li>
                    <?php if($package->package_price > 0): ?>
                    <?php if((bool)$siteSetting->is_paypal_active): ?>
                    <li class="order paypal"><a href="<?php echo e(route('order.package', $package->id)); ?>"><i class="fa fa-cc-paypal" aria-hidden="true"></i> <?php echo e(__('pay with paypal')); ?></a></li>
                    <?php endif; ?>
                    <?php if((bool)$siteSetting->is_stripe_active): ?>
                    <li class="order"><a href="<?php echo e(route('stripe.order.form', [$package->id, 'new'])); ?>"><i class="fa fa-cc-stripe" aria-hidden="true"></i> <?php echo e(__('pay with stripe')); ?></a></li>
                    <?php endif; ?>

                    <?php if((bool)$siteSetting->is_payu_active): ?>
                       <li class="order payu"><a href="<?php echo e(route('payu.order.cvsearch.package', ['package_id='.$package->id, 'type=new'])); ?>"><?php echo e(__('pay with PayU')); ?></a></li>
                    <?php endif; ?>

                    <?php else: ?>
                    <li class="order paypal"><a href="<?php echo e(route('order.free.package', $package->id)); ?>"> <?php echo e(__('Subscribe Free Package')); ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
    </div>
    <?php endif; ?>
    <!---end four-paln-->
</div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('includes.immediate_available_btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/job.theblackshort.com/public_html/resources/views/company_resume_search_packages.blade.php ENDPATH**/ ?>