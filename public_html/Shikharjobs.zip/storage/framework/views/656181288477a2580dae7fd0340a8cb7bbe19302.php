<ul class="row profilestat">
    <li class="col-md-4 col-6">
        <div class="inbox"> <i class="fa fa-clock-o" aria-hidden="true"></i>
            <h6><a href="<?php echo e(route('posted.jobs')); ?>"><?php echo e(Auth::guard('company')->user()->countOpenJobs()); ?></a></h6>
            <strong><?php echo e(__('Open Jobs')); ?></strong> </div>
    </li>
    <li class="col-md-4 col-6">
        <div class="inbox"> <i class="fa fa-user-o" aria-hidden="true"></i>
            <h6><a href="<?php echo e(route('company.followers')); ?>"><?php echo e(Auth::guard('company')->user()->countFollowers()); ?></a></h6>
            <strong><?php echo e(__('Followers')); ?></strong> </div>
    </li>
    
</ul><?php /**PATH /home/admin/web/shikharjobs.com/public_html/resources/views/includes/company_dashboard_stats.blade.php ENDPATH**/ ?>